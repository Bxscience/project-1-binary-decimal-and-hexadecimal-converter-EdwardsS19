package com.example.sheys.calculatorconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void convert(View view){
        Spinner spinner1 = findViewById(R.id.spinner1);
        String inType = spinner1.getSelectedItem().toString();
        Spinner spinner2 = findViewById(R.id.spinner2);
        String outType = spinner2.getSelectedItem().toString();
        EditText editText = findViewById(R.id.editText);
        String input = editText.getText().toString();
        TextView output = findViewById(R.id.textView);
        String dec = "";
        String converted = "";

        //converts non-decimal inputs to decimal
        if (inType.equals("Binary")) {
            dec = Integer.toString(Integer.parseInt(input, 2));
        }
        if (inType.equals("Decimal")) {
            dec = input;
        }
        if (inType.equals("Hexadecimal")) {
            dec = Integer.toString(Integer.parseInt(input, 16));
        }

        //converts decimal to desired output type and stores in 'converted'
        if (outType.equals("Binary")) {
            converted = Integer.toBinaryString(Integer.parseInt(dec));
        }
        if (outType.equals("Decimal")) {
            converted = dec;
        }
        if (outType.equals("Hexadecimal")) {
            converted = Integer.toHexString(Integer.parseInt(dec));
        }

        //Displays converted value
        output.setText(converted);
    }
}
